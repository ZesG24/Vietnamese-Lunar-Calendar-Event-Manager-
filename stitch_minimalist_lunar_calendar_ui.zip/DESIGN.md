---
name: Lịch Âm Nocturne
colors:
  surface: '#161212'
  surface-dim: '#161212'
  surface-bright: '#3d3837'
  surface-container-lowest: '#110d0c'
  surface-container-low: '#1f1b1a'
  surface-container: '#231f1e'
  surface-container-high: '#2e2928'
  surface-container-highest: '#393432'
  on-surface: '#eae0de'
  on-surface-variant: '#debfbd'
  inverse-surface: '#eae0de'
  inverse-on-surface: '#342f2e'
  outline: '#a68a88'
  outline-variant: '#574140'
  surface-tint: '#ffb3ae'
  primary: '#ffb3ae'
  on-primary: '#67040e'
  primary-container: '#a03232'
  on-primary-container: '#ffc1bd'
  inverse-primary: '#a73737'
  secondary: '#e2c195'
  on-secondary: '#402d0c'
  secondary-container: '#594320'
  on-secondary-container: '#d0b085'
  tertiary: '#87d4ca'
  on-tertiary: '#003732'
  tertiary-container: '#00645c'
  on-tertiary-container: '#90ded3'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ae'
  on-primary-fixed: '#410005'
  on-primary-fixed-variant: '#871f22'
  secondary-fixed: '#ffddb0'
  secondary-fixed-dim: '#e2c195'
  on-secondary-fixed: '#281800'
  on-secondary-fixed-variant: '#594320'
  tertiary-fixed: '#a3f1e6'
  tertiary-fixed-dim: '#87d4ca'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#161212'
  on-background: '#eae0de'
  surface-variant: '#393432'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 44px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system reimagines the traditional Vietnamese Lunar Calendar (*Lịch Âm*) as a nocturnal lacquer-and-crimson editorial experience. Designed for an Android mobile audience seeking daily lunar dates, auspicious hours (*giờ hoàng đạo*), and cultural observances, the interface evokes quiet contemplation, reverence, and tactile precision.

The visual style blends **Minimalism** with **High-Contrast Editorial** sensibility:
- **Nocturnal Lacquer & Crimson:** Deep obsidian and charcoal-lacquer surfaces replace bright paper, allowing muted crimson accents and warm ivory typography to command focus without visual fatigue.
- **Architectural Restraint:** Crisp, lightly softened corners (`4px` base) and generous negative space frame high-contrast `Bodoni Moda` lunar numerals like a printed almanac.
- **Tactile Hierarchy:** Subtle tonal shifts and hairline borders define structure without heavy drop shadows or neon gradients.

## Colors

The palette is anchored in `dark` mode, drawing inspiration from aged lacquerware, vermilion seal ink, and warm parchment:

- **Primary (`#A03232`):** Muted crimson-vermilion used for auspicious lunar highlights, active date indicators, primary actions, and solar-lunar festival badges.
- **Secondary (`#C8A97E`):** Warm brushed gold-sand used sparingly for secondary accents, auspicious hour markers (*giờ hoàng đạo*), and subtle editorial dividers.
- **Neutral (`#1A1615`):** Deep warm obsidian-brown serving as the foundational canvas, paired with elevated lacquer-charcoal surfaces (`#241F1D`, `#2E2725`) and warm ivory text (`#F3ECE1`) for comfortable contrast.
- **Semantic & State:** Avoid saturated neon greens or blues; use muted jade (`#5B8A72`) for favorable indicators and warm amber (`#C48B45`) for cautionary notes.

## Typography

The typographic pairing contrasts editorial drama with Vietnamese diacritic clarity:
- **Display & Headlines (`Bodoni Moda`):** Reserved for hero lunar date numerals, month headers, and solar-term (*Tiết Khí*) titles. Use `display-lg-mobile` on compact Android viewports to preserve breathing room.
- **Body & UI Labels (`Be Vietnam Pro`):** Engineered with generous diacritic spacing for Vietnamese, ensuring crisp legibility in daily almanac descriptions, auspicious hour lists, and navigation controls.

## Layout & Spacing

This design system uses a **Fluid Grid** tailored for Android Material 3 ergonomics, maintaining a 4-column mobile grid with `1rem` (`16px`) gutters and `1.25rem` (`20px`) outer margins.

- **Mobile (`< 600dp`):** 4-column fluid grid. Primary lunar date cards span all 4 columns; secondary widgets (auspicious hours, *Can Chi* details) pair in 2-column splits.
- **Tablet (`600dp – 839dp`):** 8-column fluid grid with `1.5rem` (`24px`) margins, allowing side-by-side month grid and daily detail panes.
- **Desktop / Foldables (`>= 840dp`):** 12-column fluid grid with `2rem` (`32px`) margins, supporting a persistent navigation rail and multi-pane almanac view.

## Elevation & Depth

Hierarchy is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy drop shadows:
- **Surface Tiers:** Stack `#1A1615` (base canvas), `#241F1D` (cards and sheets), and `#2E2725` (elevated dialogs or active states) to create subtle nocturnal depth.
- **Hairline Borders:** Use `1px` low-opacity warm borders (`rgba(243, 236, 225, 0.08)`) to define card edges and calendar grid cells cleanly.
- **No Heavy Shadows:** Avoid ambient blurs or glowing gradients; let tonal contrast and crimson accents guide the eye.

## Shapes

With `roundedness` set to `1` (Soft), the design system favors crisp architectural corners (`0.25rem` / `4px` base) that echo traditional woodblock prints and lacquerware:
- **Standard Elements (`4px`):** Buttons, input fields, and calendar day cells.
- **Large Containers (`8px` / `rounded-lg`):** Daily almanac cards and bottom sheets.
- **Extra-Large Containers (`12px` / `rounded-xl`):** Modal dialogs and featured festival banners.

## Components

- **Buttons:** Primary actions use `#A03232` fill with `#F3ECE1` text (`4px` radius, `48dp` minimum touch target). Secondary actions use `1px` hairline borders (`rgba(243, 236, 225, 0.2)`) with transparent backgrounds.
- **Chips:** Compact `4px` rounded pills for filtering auspicious activities (*Xuất hành*, *Cưới hỏi*). Active chips use `#A03232` at 20% opacity with a `#A03232` border.
- **Cards:** `#241F1D` surface with `8px` corners, `1px` subtle warm border, and `1rem` internal padding.
- **Lists:** Single-line and two-line rows for *Giờ Hoàng Đạo* (auspicious hours) separated by `1px` dividers (`rgba(243, 236, 225, 0.06)`).
- **Checkboxes & Radio Buttons:** `4px` rounded square checkboxes and circular radios using `#A03232` when selected, with `#F3ECE1` checkmarks.
- **Input Fields:** `#241F1D` fill, `4px` corners, `1px` border that transitions to `#A03232` on focus.
- **Lunar Calendar Grid:** 7-column matrix where the active date is framed in `#A03232`, solar dates sit in `Be Vietnam Pro`, and lunar dates sit below in `Bodoni Moda` or muted gold (`#C8A97E`) for *Mùng 1* and *Rằm* (1st and 15th).